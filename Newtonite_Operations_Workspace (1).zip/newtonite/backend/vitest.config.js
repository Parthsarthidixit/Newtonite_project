import { defineConfig } from 'vitest/config';
export default defineConfig({ test: { testTimeout: 30000, hookTimeout: 180000, fileParallelism: false } });
